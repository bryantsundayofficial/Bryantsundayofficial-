BRYANT SUNDAY WEBSITE
======================

This package is ready for static hosting.

MAIN FILE:
index.html

The website is self-contained: the profile photo and LOVE & MONEY cover are embedded in index.html, so no separate image files are required.

CLOUDFLARE PAGES:
1. Create a Cloudflare account.
2. Go to Workers & Pages.
3. Create application > Get started > Drag and drop your files.
4. Upload this entire folder (or the ZIP package).
5. Choose a project name such as bryant-sunday.
6. Deploy.

Cloudflare Pages will provide a public pages.dev address after deployment.

All music/social links in the website point to the links supplied by Bryant Sunday.
